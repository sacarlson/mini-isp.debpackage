<?php
 header("Cache-Control: no-cache, must-revalidate");
 header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
 header( 'refresh: 0; url= http://freenet.surething.biz/index.php' );
?>
