<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Reviews');
define('HEADING_TITLE', 'Read What Others Are Saying');
define('TEXT_OF_5_STARS', '%s of 5 Stars!');
?>