<?php
/*
  $Id $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Log Off');
define('NAVBAR_TITLE', 'Log Off');
define('TEXT_MAIN', 'You have been logged off your account. It is now safe to leave the computer.<br /><br />Your shopping cart has been saved, the items inside it will be restored whenever you log back into your account.');
?>
