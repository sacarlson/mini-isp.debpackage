<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'My Account');
define('NAVBAR_TITLE_2', 'Address Book');

define('HEADING_TITLE', 'My Personal Address Book');

define('PRIMARY_ADDRESS_TITLE', 'Primary Address');
define('PRIMARY_ADDRESS_DESCRIPTION', 'This address is used as the pre-selected shipping and billing address for orders placed on this store.<br /><br />This address is also used as the base for product and service tax calculations.');

define('ADDRESS_BOOK_TITLE', 'Address Book Entries');

define('PRIMARY_ADDRESS', '(primary address)');

define('TEXT_MAXIMUM_ENTRIES', '<font color="#ff0000"><strong>NOTE:</strong></font> A maximum of %s address book entries allowed.');
?>
