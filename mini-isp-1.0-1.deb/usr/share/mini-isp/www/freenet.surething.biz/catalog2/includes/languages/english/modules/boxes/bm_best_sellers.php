<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_BEST_SELLERS_TITLE', 'Best Sellers');
  define('MODULE_BOXES_BEST_SELLERS_DESCRIPTION', 'Show global and category best sellers');
  define('MODULE_BOXES_BEST_SELLERS_BOX_TITLE', 'Bestsellers');
?>
