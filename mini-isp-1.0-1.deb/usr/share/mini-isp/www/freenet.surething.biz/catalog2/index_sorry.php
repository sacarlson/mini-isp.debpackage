<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=utf-8">
	<TITLE>FreeNET Login Screen</TITLE>
	<meta name="generator" content="Bluefish 1.0.7">
	<meta name="author" content="sacarlson">
	<META NAME="CREATED" CONTENT="20070614;9084500">
	<META NAME="CHANGEDBY" CONTENT="scott carlson">
	<META NAME="CHANGED" CONTENT="20070623;10204100">
	<META HTTP-EQUIV="Expires" CONTENT="-1">
	<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
	<META HTTP-EQUIV="Cache-control" CONTENT="no-cache">
	<META HTTP-EQUIV="Cache" CONTENT="no-cache">
	<META HTTP-EQUIV="Expires" CONTENT="thu, 01 Jan 1998 12:00:00 GMT">
	<STYLE TYPE="text/css">
	<!--
		@page { size: 8.5in 11in; margin: 0.79in }
		P { margin-bottom: 0.08in }
	-->
	</STYLE>
</HEAD>
<BODY LANG="en-US" DIR="LTR">
<P ALIGN=LEFT STYLE="margin-bottom: 0in"><IMG SRC="../freenet.png" NAME="graphics1" ALIGN=BASELINE WIDTH=400 HEIGHT=93 BORDER=0>
</P>

<P STYLE="margin-bottom: 0in"><FONT SIZE=5>Dear FreeNET users</FONT></P>
<P STYLE="margin-bottom: 0in"><FONT SIZE=5>I am very sorry to have to
inform the users of FreeNET that we have had to suspend the sale of
Wifi contracts due to resent abuses of the FreeNET wifi network.
 FreeNET has operated on trust and
faith in the mostly good people that have made use of FreeNET over
many years.   It's a shame when just a few people can mess things up
for the entire community by repetitively failing to provide accurate
billing information for cash on delivery contracts.   FreeNET is
nonprofit and hasn't the time nor the resources to deal with these
kind of abuses.    I'm sure you will find there are many other
wireless Networks to choose from in the local aria although maybe not
as fast or relible or as inexpensive as FreeNET but for those that
are not already members in standing that's what you will have to deal
with.</FONT></P>
<P STYLE="margin-bottom: 0in">  <FONT SIZE=5>Thanks You for your
understanding.</FONT></P>

</BODY>
</HTML>
